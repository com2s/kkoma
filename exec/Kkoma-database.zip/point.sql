create table point
(
    balance int not null,
    id      bigint auto_increment
        primary key
);

INSERT INTO kkoma.point (balance, id) VALUES (200000, 1);
INSERT INTO kkoma.point (balance, id) VALUES (0, 2);
INSERT INTO kkoma.point (balance, id) VALUES (0, 3);
INSERT INTO kkoma.point (balance, id) VALUES (288000, 4);
INSERT INTO kkoma.point (balance, id) VALUES (919000, 5);
INSERT INTO kkoma.point (balance, id) VALUES (0, 6);
INSERT INTO kkoma.point (balance, id) VALUES (0, 7);
INSERT INTO kkoma.point (balance, id) VALUES (0, 8);
INSERT INTO kkoma.point (balance, id) VALUES (0, 9);
INSERT INTO kkoma.point (balance, id) VALUES (0, 10);
INSERT INTO kkoma.point (balance, id) VALUES (0, 11);
INSERT INTO kkoma.point (balance, id) VALUES (0, 12);
INSERT INTO kkoma.point (balance, id) VALUES (0, 13);
INSERT INTO kkoma.point (balance, id) VALUES (100000, 14);
INSERT INTO kkoma.point (balance, id) VALUES (99985000, 15);
INSERT INTO kkoma.point (balance, id) VALUES (-100000, 16);
INSERT INTO kkoma.point (balance, id) VALUES (25000, 17);
INSERT INTO kkoma.point (balance, id) VALUES (84000, 18);
INSERT INTO kkoma.point (balance, id) VALUES (50000, 94);
INSERT INTO kkoma.point (balance, id) VALUES (0, 95);
INSERT INTO kkoma.point (balance, id) VALUES (277000, 96);
INSERT INTO kkoma.point (balance, id) VALUES (0, 97);
INSERT INTO kkoma.point (balance, id) VALUES (450000, 98);
INSERT INTO kkoma.point (balance, id) VALUES (0, 99);
INSERT INTO kkoma.point (balance, id) VALUES (0, 100);
INSERT INTO kkoma.point (balance, id) VALUES (10000, 101);
INSERT INTO kkoma.point (balance, id) VALUES (10000, 102);
INSERT INTO kkoma.point (balance, id) VALUES (10000, 103);

create table deal
(
    is_completed  bit          null,
    cancelled_at  datetime(6)  null,
    created_at    datetime(6)  null,
    id            bigint auto_increment
        primary key,
    member_id     bigint       null,
    modified_at   datetime(6)  null,
    product_id    bigint       null,
    selected_time datetime(6)  null,
    code          varchar(255) null,
    constraint FK8upm3li05g6r9bkuac5adumkr
        foreign key (member_id) references member (id),
    constraint FKssa4j4c9uaou3wsbh9ktb343p
        foreign key (product_id) references product (id)
);

INSERT INTO kkoma.deal (is_completed, cancelled_at, created_at, id, member_id, modified_at, product_id, selected_time, code) VALUES (false, null, '2024-04-03 18:15:16.238945', 1, 4, '2024-04-03 18:15:16.238945', 3, '2024-04-05 05:20:00.000000', 'ea3eb385-9da5-43fc-87e0-f2f446ab227d');
INSERT INTO kkoma.deal (is_completed, cancelled_at, created_at, id, member_id, modified_at, product_id, selected_time, code) VALUES (true, null, '2024-04-03 18:54:03.715181', 2, 18, '2024-04-03 19:12:43.695007', 11, '2024-04-03 23:20:00.000000', 'fdd9f3ba-b9ca-4648-91d8-4445c6f0e08b');
INSERT INTO kkoma.deal (is_completed, cancelled_at, created_at, id, member_id, modified_at, product_id, selected_time, code) VALUES (false, null, '2024-04-03 19:36:56.839490', 3, 1, '2024-04-03 19:36:56.839490', 20, '2024-04-06 04:00:00.000000', '53dc8f9f-9e2c-4132-93e9-e2984ef9763e');
INSERT INTO kkoma.deal (is_completed, cancelled_at, created_at, id, member_id, modified_at, product_id, selected_time, code) VALUES (false, null, '2024-04-03 19:40:57.609530', 4, 5, '2024-04-03 19:40:57.609530', 22, '2024-04-04 01:20:00.000000', 'a48ce8b6-60c6-4403-9bfb-5a1d7fac9d5c');
INSERT INTO kkoma.deal (is_completed, cancelled_at, created_at, id, member_id, modified_at, product_id, selected_time, code) VALUES (false, null, '2024-04-03 19:41:05.319730', 5, 5, '2024-04-03 19:41:05.319730', 21, '2024-04-12 13:00:00.000000', 'd77a6702-e173-4e10-aae7-e69fa35e23b3');
INSERT INTO kkoma.deal (is_completed, cancelled_at, created_at, id, member_id, modified_at, product_id, selected_time, code) VALUES (false, null, '2024-04-03 20:58:32.286112', 6, 5, '2024-04-03 20:58:32.286112', 24, '2024-04-05 09:20:00.000000', '61ca7bdc-6df8-4767-b9b3-5a093511c4c2');
INSERT INTO kkoma.deal (is_completed, cancelled_at, created_at, id, member_id, modified_at, product_id, selected_time, code) VALUES (false, null, '2024-04-03 21:03:54.187150', 7, 5, '2024-04-03 21:03:54.187150', 25, '2024-04-06 03:10:00.000000', 'aa2cebff-8859-4f49-9536-93fc6a673640');
INSERT INTO kkoma.deal (is_completed, cancelled_at, created_at, id, member_id, modified_at, product_id, selected_time, code) VALUES (false, null, '2024-04-03 21:15:24.021295', 13, 1, '2024-04-03 21:15:24.021295', 19, '2024-04-04 04:00:00.000000', '3cdd199e-8acc-42d8-a63d-aef2e3134f2c');
INSERT INTO kkoma.deal (is_completed, cancelled_at, created_at, id, member_id, modified_at, product_id, selected_time, code) VALUES (true, null, '2024-04-03 21:31:00.772267', 14, 18, '2024-04-03 22:19:11.360610', 23, '2024-04-04 06:00:00.000000', 'b95d4b64-2edb-41cf-a8eb-9633edfc7077');
INSERT INTO kkoma.deal (is_completed, cancelled_at, created_at, id, member_id, modified_at, product_id, selected_time, code) VALUES (false, null, '2024-04-03 22:35:46.803011', 15, 15, '2024-04-03 22:35:46.803011', 148, '2024-04-04 15:30:15.209000', '1db4eb14-276b-4a5a-b1a7-da1d48fa801e');
INSERT INTO kkoma.deal (is_completed, cancelled_at, created_at, id, member_id, modified_at, product_id, selected_time, code) VALUES (false, null, '2024-04-03 22:54:12.851895', 16, 15, '2024-04-03 22:54:12.851895', 149, '2024-04-03 23:40:00.000000', 'b30404f1-54ff-448f-827c-54890db16f23');
INSERT INTO kkoma.deal (is_completed, cancelled_at, created_at, id, member_id, modified_at, product_id, selected_time, code) VALUES (false, null, '2024-04-04 02:08:09.954039', 17, 15, '2024-04-04 02:08:09.954039', 26, '2024-04-04 03:09:40.000000', '55b1d289-a8e6-4322-903e-69ad3994e3cb');
INSERT INTO kkoma.deal (is_completed, cancelled_at, created_at, id, member_id, modified_at, product_id, selected_time, code) VALUES (false, null, '2024-04-04 08:41:02.294319', 18, 19, '2024-04-04 08:41:02.294319', 160, '2024-04-04 00:00:00.000000', '8ce469c3-1578-48aa-8b09-f7563db0d397');
INSERT INTO kkoma.deal (is_completed, cancelled_at, created_at, id, member_id, modified_at, product_id, selected_time, code) VALUES (true, null, '2024-04-04 08:47:50.837980', 19, 107, '2024-04-04 08:59:15.088282', 156, '2024-04-04 09:50:00.000000', '9a58b3f5-a0ba-472b-b85d-2d968ef72450');
INSERT INTO kkoma.deal (is_completed, cancelled_at, created_at, id, member_id, modified_at, product_id, selected_time, code) VALUES (false, null, '2024-04-04 09:03:34.574007', 20, 107, '2024-04-04 09:03:34.574007', 182, '2024-04-04 10:10:00.000000', '735246de-dc9c-4a17-9943-ab5f8e01a39a');
INSERT INTO kkoma.deal (is_completed, cancelled_at, created_at, id, member_id, modified_at, product_id, selected_time, code) VALUES (false, null, '2024-04-04 09:09:56.264788', 21, 107, '2024-04-04 09:09:56.264788', 184, '2024-04-04 10:10:00.000000', '19264486-0a4d-463c-8d9a-f33454ed3c09');
INSERT INTO kkoma.deal (is_completed, cancelled_at, created_at, id, member_id, modified_at, product_id, selected_time, code) VALUES (false, null, '2024-04-04 10:11:57.594869', 25, 19, '2024-04-04 10:11:57.594869', 147, '2024-04-03 21:30:00.000000', '246cea6c-bc14-48f0-8993-bd721b465aa5');
INSERT INTO kkoma.deal (is_completed, cancelled_at, created_at, id, member_id, modified_at, product_id, selected_time, code) VALUES (false, null, '2024-04-04 10:15:56.619196', 26, 5, '2024-04-04 10:15:56.619196', 171, '2024-04-05 11:20:00.000000', 'e00566e8-32c8-40f6-bbce-f4cc36919c94');
INSERT INTO kkoma.deal (is_completed, cancelled_at, created_at, id, member_id, modified_at, product_id, selected_time, code) VALUES (false, null, '2024-04-04 10:21:10.424025', 27, 5, '2024-04-04 10:21:10.424025', 154, '2024-04-04 11:20:00.000000', '21e55b2f-5155-4b99-8a7f-b2639e98fa5b');
INSERT INTO kkoma.deal (is_completed, cancelled_at, created_at, id, member_id, modified_at, product_id, selected_time, code) VALUES (true, null, '2024-04-04 10:58:03.738716', 28, 5, '2024-04-04 10:58:45.564218', 191, '2024-04-04 04:30:00.000000', '792e3502-604e-4a11-b1d4-a6b9a9ef6ad0');

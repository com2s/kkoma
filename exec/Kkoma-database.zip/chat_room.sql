create table chat_room
(
    created_at  datetime(6) null,
    id          bigint auto_increment
        primary key,
    modified_at datetime(6) null
);

INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 16:52:33.823620', 1, '2024-04-03 16:52:33.823620');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 16:54:17.001682', 2, '2024-04-03 16:54:17.001682');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 16:58:14.647612', 3, '2024-04-03 16:58:14.647612');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 17:10:21.000457', 4, '2024-04-03 17:10:21.000457');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 17:11:07.098860', 5, '2024-04-03 17:11:07.098860');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 17:15:31.587965', 6, '2024-04-03 17:15:31.587965');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 17:19:27.275496', 7, '2024-04-03 17:19:27.275496');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 17:20:06.805011', 8, '2024-04-03 17:20:06.805011');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 17:22:40.734066', 9, '2024-04-03 17:22:40.734066');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 17:32:48.922394', 10, '2024-04-03 17:32:48.922394');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 17:39:19.979550', 11, '2024-04-03 17:39:19.979550');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 17:41:55.295788', 12, '2024-04-03 17:41:55.295788');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 17:45:10.625179', 13, '2024-04-03 17:45:10.625179');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 17:48:28.063486', 14, '2024-04-03 17:48:28.063486');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 17:53:18.484987', 15, '2024-04-03 17:53:18.484987');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 17:39:19.979550', 16, '2024-04-03 17:39:19.979550');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 19:12:08.629665', 17, '2024-04-03 19:12:08.629665');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 19:37:17.939351', 18, '2024-04-03 19:37:17.939351');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 20:53:19.762692', 19, '2024-04-03 20:53:19.762692');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 20:57:35.146058', 20, '2024-04-03 20:57:35.146058');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 21:01:22.403471', 21, '2024-04-03 21:01:22.403471');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 21:04:27.081222', 22, '2024-04-03 21:04:27.081222');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 21:55:52.431504', 54, '2024-04-03 21:55:52.431504');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 21:56:05.316781', 55, '2024-04-03 21:56:05.316781');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 22:01:29.661337', 56, '2024-04-03 22:01:29.661337');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 22:34:35.019994', 57, '2024-04-03 22:34:35.019994');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 22:46:44.704631', 58, '2024-04-03 22:46:44.704631');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-03 23:47:07.836915', 59, '2024-04-03 23:47:07.836915');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 00:04:18.220835', 60, '2024-04-04 00:04:18.220835');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 00:12:01.191864', 61, '2024-04-04 00:12:01.191864');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 00:12:28.704304', 62, '2024-04-04 00:12:28.704304');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 00:16:22.001304', 63, '2024-04-04 00:16:22.001304');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 00:23:16.223241', 64, '2024-04-04 00:23:16.223241');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 00:23:59.734975', 65, '2024-04-04 00:23:59.734975');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 00:33:33.320350', 66, '2024-04-04 00:33:33.320350');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 00:46:44.382388', 68, '2024-04-04 00:46:44.382388');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 00:51:26.366048', 69, '2024-04-04 00:51:26.366048');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 00:54:27.523282', 70, '2024-04-04 00:54:27.523282');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 00:59:08.912840', 71, '2024-04-04 00:59:08.912840');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 01:00:25.914614', 72, '2024-04-04 01:00:25.914614');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 01:00:43.561077', 73, '2024-04-04 01:00:43.561077');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 01:03:20.719437', 74, '2024-04-04 01:03:20.719437');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 01:06:22.438334', 75, '2024-04-04 01:06:22.438334');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 01:06:24.472620', 76, '2024-04-04 01:06:24.472620');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 01:08:15.441143', 77, '2024-04-04 01:08:15.441143');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 01:10:58.824230', 78, '2024-04-04 01:10:58.824230');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 01:13:14.418592', 79, '2024-04-04 01:13:14.418592');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 01:13:54.827132', 80, '2024-04-04 01:13:54.827132');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 01:15:14.467908', 81, '2024-04-04 01:15:14.467908');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 03:22:27.353989', 82, '2024-04-04 03:22:27.353989');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 03:25:02.415725', 83, '2024-04-04 03:25:02.415725');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 03:27:38.581391', 84, '2024-04-04 03:27:38.581391');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 03:33:15.759530', 85, '2024-04-04 03:33:15.759530');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 03:35:39.121831', 86, '2024-04-04 03:35:39.121831');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 03:38:34.502172', 87, '2024-04-04 03:38:34.502172');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 08:49:13.121138', 88, '2024-04-04 08:49:13.121138');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 09:02:00.357409', 89, '2024-04-04 09:02:00.357409');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 09:02:39.725308', 90, '2024-04-04 09:02:39.725308');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 09:02:52.840043', 91, '2024-04-04 09:02:52.840043');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 09:07:03.232790', 92, '2024-04-04 09:07:03.232790');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 09:07:07.491770', 93, '2024-04-04 09:07:07.491770');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 09:07:58.921069', 94, '2024-04-04 09:07:58.921069');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 09:13:03.224704', 95, '2024-04-04 09:13:03.224704');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 09:15:12.325987', 96, '2024-04-04 09:15:12.325987');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 09:31:04.155564', 97, '2024-04-04 09:31:04.155564');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 09:44:56.495653', 98, '2024-04-04 09:44:56.495653');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 10:01:44.674616', 99, '2024-04-04 10:01:44.674616');
INSERT INTO kkoma.chat_room (created_at, id, modified_at) VALUES ('2024-04-04 10:56:37.989083', 100, '2024-04-04 10:56:37.989083');

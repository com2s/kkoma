create table interest
(
    created_at          datetime(6) null,
    id                  bigint auto_increment
        primary key,
    interest_keyword_id bigint      null,
    member_id           bigint      null,
    modified_at         datetime(6) null,
    constraint FKdaoic8rc1mgn8957y4ayx0ta1
        foreign key (interest_keyword_id) references interest_keyword (id),
    constraint FKmejotk04k93xwh9v101agbduv
        foreign key (member_id) references member (id)
);


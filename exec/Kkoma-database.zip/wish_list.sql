create table wish_list
(
    is_valid    bit         null,
    created_at  datetime(6) null,
    id          bigint auto_increment
        primary key,
    member_id   bigint      null,
    modified_at datetime(6) null,
    product_id  bigint      null,
    constraint FK8rt1tquybk69qkn942joirym1
        foreign key (member_id) references member (id),
    constraint FKqn4e0ta2823kynefeg4jektp0
        foreign key (product_id) references product (id)
);

INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 17:01:30.068670', 1, 2, '2024-04-03 17:01:30.068670', 3);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 17:10:48.697930', 2, 5, '2024-04-03 17:10:48.697930', 3);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 17:49:35.517520', 3, 14, '2024-04-03 17:49:35.517520', 19);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 17:50:06.349389', 4, 14, '2024-04-03 17:50:06.349389', 18);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 17:50:08.152499', 5, 14, '2024-04-03 17:50:08.152499', 17);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 17:50:10.169491', 6, 14, '2024-04-03 17:50:10.169491', 16);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 17:50:39.987283', 7, 15, '2024-04-03 17:50:39.987283', 16);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 17:50:42.441363', 8, 15, '2024-04-03 17:50:42.441363', 17);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 17:50:45.444749', 9, 15, '2024-04-03 17:50:45.444749', 18);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 17:51:08.085938', 10, 16, '2024-04-03 17:51:08.085938', 16);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 17:51:10.176658', 11, 16, '2024-04-03 17:51:10.176658', 17);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 18:59:04.868368', 12, 14, '2024-04-03 18:59:04.868368', 20);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 18:59:20.273669', 13, 15, '2024-04-03 18:59:20.273669', 19);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 18:59:49.546724', 14, 16, '2024-04-03 18:59:49.546724', 20);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 18:59:51.858770', 15, 16, '2024-04-03 18:59:51.858770', 19);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 18:59:54.022913', 16, 16, '2024-04-03 18:59:54.022913', 18);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 19:01:26.610566', 17, 5, '2024-04-03 19:01:26.610566', 1);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 19:37:58.337052', 18, 19, '2024-04-03 19:37:58.337052', 21);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 20:38:01.498000', 19, 19, '2024-04-03 19:38:01.498263', 19);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 20:38:04.285000', 20, 19, '2024-04-03 19:38:04.285283', 18);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 20:38:08.845000', 21, 19, '2024-04-03 19:38:08.845308', 20);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 21:04:54.000615', 22, 18, '2024-04-03 21:04:54.000615', 17);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 23:34:17.836575', 75, 19, '2024-04-03 23:34:17.836575', 16);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 23:34:20.417280', 76, 19, '2024-04-03 23:34:20.417280', 17);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 23:34:25.188517', 77, 19, '2024-04-03 23:34:25.188517', 25);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 23:34:31.084530', 78, 19, '2024-04-03 23:34:31.084530', 23);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-03 23:49:53.518374', 79, 5, '2024-04-03 23:49:53.518374', 149);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 00:00:05.919182', 80, 19, '2024-04-04 00:00:05.919182', 24);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 00:17:47.993343', 81, 18, '2024-04-04 00:17:47.993343', 150);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 00:19:02.403145', 82, 1, '2024-04-04 00:19:02.403145', 150);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 00:20:11.560088', 83, 19, '2024-04-04 00:20:15.548558', 150);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 00:21:46.921926', 84, 1, '2024-04-04 00:21:46.921926', 151);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 00:27:45.969839', 85, 19, '2024-04-04 00:27:45.969839', 155);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 00:28:03.774871', 86, 19, '2024-04-04 00:28:03.774871', 152);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 00:56:23.357256', 92, 19, '2024-04-04 00:56:23.357256', 160);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 00:57:06.728467', 93, 19, '2024-04-04 00:57:06.728467', 161);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 00:57:09.389018', 94, 19, '2024-04-04 00:57:09.389018', 157);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 01:01:40.199918', 95, 5, '2024-04-04 01:01:40.199918', 163);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 01:07:26.028768', 96, 19, '2024-04-04 01:07:26.028768', 167);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 01:08:23.022423', 97, 1, '2024-04-04 01:08:23.022423', 167);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 08:46:42.091000', 98, 5, '2024-04-04 02:18:20.663875', 171);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 02:18:27.327410', 99, 5, '2024-04-04 02:18:27.327410', 169);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 02:18:35.378553', 100, 5, '2024-04-04 02:18:35.378553', 164);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 02:19:49.261027', 101, 19, '2024-04-04 02:19:49.261027', 164);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 02:32:00.281115', 102, 16, '2024-04-04 02:32:00.281115', 163);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 02:32:10.596367', 103, 16, '2024-04-04 02:32:10.596367', 151);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 02:32:15.745719', 104, 14, '2024-04-04 02:32:15.745719', 165);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 08:46:42.091000', 105, 14, '2024-04-04 02:32:18.111241', 171);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 02:32:21.557769', 106, 14, '2024-04-04 02:32:21.557769', 164);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 09:46:42.091000', 107, 14, '2024-04-04 02:32:24.711822', 172);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 08:46:42.091000', 108, 14, '2024-04-04 02:32:27.133042', 170);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 02:32:54.769666', 109, 16, '2024-04-04 02:32:54.769666', 168);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 02:33:00.739145', 110, 16, '2024-04-04 02:33:00.739145', 166);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 02:33:11.537502', 111, 16, '2024-04-04 02:33:11.537502', 152);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 02:33:21.807839', 112, 16, '2024-04-04 02:33:21.807839', 1);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 02:33:41.849444', 113, 16, '2024-04-04 02:33:41.849444', 153);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 08:46:42.091000', 114, 16, '2024-04-04 02:34:16.651836', 170);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 02:34:26.662858', 115, 16, '2024-04-04 02:34:26.662858', 15);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 03:12:52.480173', 116, 105, '2024-04-04 03:12:52.480173', 155);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 03:13:20.864163', 117, 105, '2024-04-04 03:13:20.864163', 15);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 03:13:38.931149', 118, 105, '2024-04-04 03:13:38.931149', 170);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 03:13:51.073375', 119, 105, '2024-04-04 03:13:51.073375', 152);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 03:14:06.990528', 120, 105, '2024-04-04 03:14:06.990528', 156);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 09:46:42.091000', 121, 106, '2024-04-04 03:18:56.389090', 172);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 06:30:00.000000', 122, 106, '2024-04-04 03:18:59.833485', 170);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 06:30:00.000000', 123, 106, '2024-04-04 03:19:12.687492', 155);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 06:30:00.000000', 124, 106, '2024-04-04 03:19:34.123538', 152);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 06:30:00.000000', 125, 106, '2024-04-04 03:19:40.688412', 156);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 07:52:59.324116', 126, 107, '2024-04-04 07:52:59.324116', 156);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 07:57:32.800692', 127, 19, '2024-04-04 07:57:32.800692', 14);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 07:57:37.977030', 128, 19, '2024-04-04 07:57:37.977030', 22);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 07:57:41.239020', 129, 19, '2024-04-04 07:57:41.239020', 154);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 07:57:45.618013', 130, 19, '2024-04-04 07:57:45.618013', 151);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 08:58:29.578428', 131, 19, '2024-04-04 08:58:29.578428', 15);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 09:03:04.221545', 132, 107, '2024-04-04 09:03:04.221545', 182);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 09:46:42.091000', 133, 1, '2024-04-04 09:46:42.091463', 186);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 09:46:47.790067', 134, 1, '2024-04-04 09:46:47.790067', 184);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 09:30:00.000000', 135, 14, '2024-04-04 09:30:00.000000', 25);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 09:30:00.000000', 136, 14, '2024-04-04 09:30:00.000000', 168);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 09:30:00.000000', 137, 14, '2024-04-04 09:30:00.000000', 12);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 09:30:00.000000', 138, 15, '2024-04-04 09:30:00.000000', 25);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 09:30:00.000000', 139, 15, '2024-04-04 09:30:00.000000', 168);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 09:30:00.000000', 140, 15, '2024-04-04 09:30:00.000000', 12);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 09:30:00.000000', 141, 16, '2024-04-04 09:30:00.000000', 25);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 09:30:00.000000', 142, 16, '2024-04-04 09:30:00.000000', 168);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 09:30:00.000000', 143, 16, '2024-04-04 09:30:00.000000', 12);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 10:21:52.682296', 144, 19, '2024-04-04 10:21:52.682296', 163);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 10:22:00.757429', 145, 19, '2024-04-04 10:22:00.757429', 186);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 10:30:00.000000', 150, 107, '2024-04-04 10:30:00.000000', 24);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 10:30:00.000000', 151, 107, '2024-04-04 10:30:00.000000', 25);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 10:30:00.000000', 152, 107, '2024-04-04 10:30:00.000000', 26);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 10:30:00.000000', 154, 2, '2024-04-04 10:30:00.000000', 24);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 10:30:00.000000', 155, 2, '2024-04-04 10:30:00.000000', 25);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 10:30:00.000000', 156, 2, '2024-04-04 10:30:00.000000', 26);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 10:30:00.000000', 157, 2, '2024-04-04 10:30:00.000000', 175);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 10:30:00.000000', 158, 1, '2024-04-04 10:30:00.000000', 24);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 10:30:00.000000', 159, 1, '2024-04-04 10:30:00.000000', 25);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 10:30:00.000000', 160, 1, '2024-04-04 10:30:00.000000', 26);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 10:30:00.000000', 161, 1, '2024-04-04 10:30:00.000000', 175);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 10:30:00.000000', 162, 4, '2024-04-04 10:30:00.000000', 175);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 10:30:00.000000', 163, 4, '2024-04-04 10:30:00.000000', 26);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 10:30:00.000000', 164, 4, '2024-04-04 10:30:00.000000', 25);
INSERT INTO kkoma.wish_list (is_valid, created_at, id, member_id, modified_at, product_id) VALUES (true, '2024-04-04 10:30:00.000000', 165, 4, '2024-04-04 10:30:00.000000', 24);

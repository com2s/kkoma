create table kid
(
    birth_date  date                               null,
    cloth_size  int                                null,
    shoe_size   int                                null,
    created_at  datetime(6)                        null,
    id          bigint auto_increment
        primary key,
    member_id   bigint                             null,
    modified_at datetime(6)                        null,
    name        varchar(50)                        null,
    gender      enum ('MALE', 'FEMALE', 'UNKNOWN') null,
    constraint FKsc85si9y93pc6uoqed39bxo3c
        foreign key (member_id) references member (id)
);

INSERT INTO kkoma.kid (birth_date, cloth_size, shoe_size, created_at, id, member_id, modified_at, name, gender) VALUES ('2024-03-01', null, null, '2024-04-03 16:48:03.051984', 1, 1, '2024-04-04 11:06:19.653575', '지우', 'FEMALE');
INSERT INTO kkoma.kid (birth_date, cloth_size, shoe_size, created_at, id, member_id, modified_at, name, gender) VALUES ('2024-02-07', null, null, '2024-04-03 16:50:58.149126', 2, 2, '2024-04-03 16:51:34.015566', '짬뽕', 'MALE');
INSERT INTO kkoma.kid (birth_date, cloth_size, shoe_size, created_at, id, member_id, modified_at, name, gender) VALUES (null, null, null, '2024-04-03 16:53:02.541244', 3, 3, '2024-04-03 16:53:02.545363', null, null);
INSERT INTO kkoma.kid (birth_date, cloth_size, shoe_size, created_at, id, member_id, modified_at, name, gender) VALUES ('2024-02-07', null, null, '2024-04-03 16:55:52.499702', 4, 4, '2024-04-03 22:32:40.476404', '김꼬꼬', 'MALE');
INSERT INTO kkoma.kid (birth_date, cloth_size, shoe_size, created_at, id, member_id, modified_at, name, gender) VALUES ('2024-02-02', null, null, '2024-04-03 17:07:45.834290', 5, 5, '2024-04-04 02:55:41.057729', '이수현', 'FEMALE');
INSERT INTO kkoma.kid (birth_date, cloth_size, shoe_size, created_at, id, member_id, modified_at, name, gender) VALUES (null, null, null, '2024-04-03 17:17:20.754672', 8, 14, '2024-04-03 17:17:20.786118', null, null);
INSERT INTO kkoma.kid (birth_date, cloth_size, shoe_size, created_at, id, member_id, modified_at, name, gender) VALUES ('2024-04-19', null, null, '2024-04-03 17:17:45.380596', 9, 15, '2024-04-04 02:47:57.908145', '유소연', 'UNKNOWN');
INSERT INTO kkoma.kid (birth_date, cloth_size, shoe_size, created_at, id, member_id, modified_at, name, gender) VALUES ('2024-01-01', null, null, '2024-04-03 17:17:59.654252', 10, 16, '2024-04-04 02:31:41.488155', '말랑이', 'FEMALE');
INSERT INTO kkoma.kid (birth_date, cloth_size, shoe_size, created_at, id, member_id, modified_at, name, gender) VALUES ('2024-04-03', null, null, '2024-04-03 18:46:01.573903', 11, 18, '2024-04-03 18:46:44.185314', '김응애', 'FEMALE');
INSERT INTO kkoma.kid (birth_date, cloth_size, shoe_size, created_at, id, member_id, modified_at, name, gender) VALUES ('2024-04-04', null, null, '2024-04-03 19:33:36.214009', 12, 19, '2024-04-04 02:33:14.367664', '이지수', 'FEMALE');
INSERT INTO kkoma.kid (birth_date, cloth_size, shoe_size, created_at, id, member_id, modified_at, name, gender) VALUES ('2024-04-04', null, null, '2024-04-04 02:26:52.232399', 27, 105, '2024-04-04 03:12:40.696476', '복덩이', 'MALE');
INSERT INTO kkoma.kid (birth_date, cloth_size, shoe_size, created_at, id, member_id, modified_at, name, gender) VALUES ('2024-04-04', null, null, '2024-04-04 03:17:33.203949', 28, 106, '2024-04-04 03:18:50.328215', '복덩이', 'FEMALE');
INSERT INTO kkoma.kid (birth_date, cloth_size, shoe_size, created_at, id, member_id, modified_at, name, gender) VALUES ('2018-09-20', null, null, '2024-04-04 07:51:11.356644', 29, 107, '2024-04-04 07:51:53.370904', '이수호', 'FEMALE');
INSERT INTO kkoma.kid (birth_date, cloth_size, shoe_size, created_at, id, member_id, modified_at, name, gender) VALUES ('2024-04-04', null, null, '2024-04-04 08:40:45.319416', 30, 108, '2024-04-04 08:44:31.587421', '최지우', 'FEMALE');
INSERT INTO kkoma.kid (birth_date, cloth_size, shoe_size, created_at, id, member_id, modified_at, name, gender) VALUES ('2024-02-28', null, null, '2024-04-04 08:42:12.490865', 31, 109, '2024-04-04 09:24:24.353479', '김응국 2세', 'FEMALE');
INSERT INTO kkoma.kid (birth_date, cloth_size, shoe_size, created_at, id, member_id, modified_at, name, gender) VALUES ('2024-02-01', null, null, '2024-04-04 10:54:37.709216', 36, 114, '2024-04-04 10:55:03.207997', '지우', 'FEMALE');

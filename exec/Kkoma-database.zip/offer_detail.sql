create table offer_detail
(
    end_time   time(6) null,
    offer_date date    null,
    start_time time(6) null,
    id         bigint auto_increment
        primary key,
    offer_id   bigint  null,
    constraint FKa11jkxjv2v0fmj7yts6fhnoj6
        foreign key (offer_id) references offer (id)
);

INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('19:20:00', '2024-04-04', '11:30:00', 1, 1);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('19:20:00', '2024-04-19', '14:30:00', 2, 2);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-05', '04:20:00', 3, 3);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('19:30:00', '2024-04-05', '12:10:00', 4, 4);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-04', '00:00:00', 5, 5);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-04', '00:00:00', 6, 6);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('14:30:00', '2024-04-11', '10:30:00', 7, 7);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-12', '18:50:00', 8, 7);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('16:00:00', '2024-04-06', '05:20:00', 9, 8);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('10:30:00', '2024-04-03', '03:50:00', 10, 8);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('15:10:00', '2024-04-04', '10:00:00', 11, 9);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('19:30:00', '2024-04-06', '12:40:00', 12, 9);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-04', '00:00:00', 13, 10);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-05', '15:40:00', 14, 11);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('17:30:00', '2024-04-06', '09:10:00', 15, 12);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('19:20:00', '2024-04-07', '11:10:00', 16, 12);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('18:20:00', '2024-04-04', '11:30:00', 17, 13);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('14:00:00', '2024-04-03', '11:10:00', 23, 23);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('15:50:00', '2024-04-04', '13:00:00', 24, 23);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-03', '22:00:00', 25, 24);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-03', '20:20:00', 26, 25);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('17:30:00', '2024-04-03', '10:40:00', 27, 26);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('17:50:00', '2024-04-04', '10:30:00', 28, 26);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('14:20:00', '2024-04-04', '11:30:00', 29, 27);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-03', '21:30:00', 30, 28);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-03', '21:30:00', 31, 29);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-04', '00:00:00', 32, 30);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-06', '00:00:00', 33, 30);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-05', '00:00:00', 34, 31);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('16:50:00', '2024-04-12', '10:30:00', 35, 31);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('15:00:00', '2024-04-04', '02:10:00', 36, 32);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-04', '05:00:00', 37, 32);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('07:20:00', '2024-04-04', '02:30:00', 38, 33);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('19:20:00', '2024-04-04', '00:30:00', 39, 34);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-04', '00:00:00', 40, 36);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-05', '00:00:00', 41, 36);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-06', '10:00:00', 42, 37);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:00:00', '2024-04-04', '08:30:00', 43, 38);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-04', '05:40:00', 44, 39);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-05', '00:00:00', 45, 39);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('13:30:00', '2024-04-04', '05:00:00', 46, 40);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-12', '00:00:00', 47, 41);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES (null, '2024-04-06', null, 48, 41);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-04', '07:10:00', 49, 42);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-04', '08:50:00', 50, 43);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-06', '07:20:00', 53, 45);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-04', '11:20:00', 58, 48);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-05', '00:00:00', 59, 48);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-04', '11:20:00', 60, 49);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-05', '00:00:00', 61, 49);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-04', '12:30:00', 62, 50);
INSERT INTO kkoma.offer_detail (end_time, offer_date, start_time, id, offer_id) VALUES ('23:59:00', '2024-04-05', '00:00:00', 63, 50);

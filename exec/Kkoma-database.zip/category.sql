create table category
(
    id   int auto_increment
        primary key,
    name varchar(20) null
);

INSERT INTO kkoma.category (id, name) VALUES (1, '기저귀');
INSERT INTO kkoma.category (id, name) VALUES (2, '분유/이유식');
INSERT INTO kkoma.category (id, name) VALUES (3, '유아스킨/바디케어');
INSERT INTO kkoma.category (id, name) VALUES (4, '수유용품');
INSERT INTO kkoma.category (id, name) VALUES (5, '이유식용품');
INSERT INTO kkoma.category (id, name) VALUES (6, '소독/세정용품');
INSERT INTO kkoma.category (id, name) VALUES (7, '유아구강용품');
INSERT INTO kkoma.category (id, name) VALUES (8, '유아목욕용품');
INSERT INTO kkoma.category (id, name) VALUES (9, '유아위생용품');
INSERT INTO kkoma.category (id, name) VALUES (10, '유아세탁용품');
INSERT INTO kkoma.category (id, name) VALUES (11, '유아안전용품');
INSERT INTO kkoma.category (id, name) VALUES (12, '출산준비물');
INSERT INTO kkoma.category (id, name) VALUES (13, '임부복');
INSERT INTO kkoma.category (id, name) VALUES (14, '임산부용품');
INSERT INTO kkoma.category (id, name) VALUES (15, '유모차/카시트');
INSERT INTO kkoma.category (id, name) VALUES (16, '놀이방매트');
INSERT INTO kkoma.category (id, name) VALUES (17, '유아외출용품');
INSERT INTO kkoma.category (id, name) VALUES (18, '유아발육용품');
INSERT INTO kkoma.category (id, name) VALUES (19, '유아가구');
INSERT INTO kkoma.category (id, name) VALUES (20, '유아의류');
INSERT INTO kkoma.category (id, name) VALUES (21, '유아신발/잡화');
INSERT INTO kkoma.category (id, name) VALUES (22, '장난감/완구');
INSERT INTO kkoma.category (id, name) VALUES (23, '기타');

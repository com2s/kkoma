create table search_history
(
    created_at  datetime(6)  null,
    id          bigint auto_increment
        primary key,
    member_id   bigint       null,
    modified_at datetime(6)  null,
    search_word varchar(100) null,
    constraint FKf7bt6j8qucsj0iy7ghnxrgyfw
        foreign key (member_id) references member (id)
);


create table interest_keyword
(
    id   bigint auto_increment
        primary key,
    name varchar(255) null
);


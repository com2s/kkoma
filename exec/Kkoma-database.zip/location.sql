create table location
(
    x            double      null,
    y            double      null,
    created_at   datetime(6) null,
    id           bigint auto_increment
        primary key,
    modified_at  datetime(6) null,
    region_code  bigint      null,
    place_detail varchar(50) null
);

INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.07665886290631, 37.48444966218628, '2024-04-03 16:52:33.830697', 1, '2024-04-03 16:52:33.830697', 1168010300, '바로그장소');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.03729725771035, 37.50060568369148, '2024-04-03 16:54:17.003807', 2, '2024-04-03 16:54:17.003807', 1168010100, '역삼역 1번 출구');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.03965560222662, 37.50137527562267, '2024-04-03 16:58:14.649598', 3, '2024-04-03 16:58:14.649598', 1168010100, '멀캠앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.0395990290321, 37.5013234867631, '2024-04-03 17:10:21.005966', 4, '2024-04-03 17:10:21.005966', 1168010100, '멀티캠퍼스 역삼 12층 1201호');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.0218975126676, 37.51151170471786, '2024-04-03 17:11:07.101097', 5, '2024-04-03 17:11:07.101097', 1168010800, '논현역');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (111.11111, 111.11111, '2024-04-03 17:12:02.132948', 6, '2024-04-03 17:12:02.132948', 1111010100, '지하철역 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (111.11111, 111.11111, '2024-04-03 17:12:02.266835', 7, '2024-04-03 17:12:02.266835', 1111010100, '지하철역 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (111.11111, 111.11111, '2024-04-03 17:12:02.389847', 8, '2024-04-03 17:12:02.389847', 1111010100, '지하철역 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (111.11111, 111.11111, '2024-04-03 17:12:02.503046', 9, '2024-04-03 17:12:02.503046', 1111010100, '지하철역 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (111.11111, 111.11111, '2024-04-03 17:12:02.625992', 10, '2024-04-03 17:12:02.625992', 1111010100, '지하철역 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.02846381776874, 37.49778799289762, '2024-04-03 17:15:31.589837', 11, '2024-04-03 17:15:31.589837', 1168010100, '스타벅스 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.03731990720284, 37.50066874695678, '2024-04-03 17:19:27.277438', 12, '2024-04-03 17:19:27.277438', 1168010100, '역삼역 1번 출구');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (1.111, 2.111, '2024-04-03 17:20:06.806955', 13, '2024-04-03 17:20:06.806955', 1168010100, '역삼역 1번 출구 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (1.111, 2.111, '2024-04-03 17:22:40.736520', 14, '2024-04-03 17:22:40.736520', 1168010100, '역삼역 1번 출구 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.02402012170158, 37.49964505297895, '2024-04-03 17:32:48.924319', 15, '2024-04-03 17:32:48.924319', 1165010800, '서초초등학교 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (126.98242914539514, 37.4860319693328, '2024-04-03 17:39:19.981698', 16, '2024-04-03 17:39:19.981698', 1165010100, '이수역 3번 출구');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.02454981160967, 37.49405870325851, '2024-04-03 17:41:55.297686', 17, '2024-04-03 17:41:55.297686', 1165010800, '서운중학교 운동장');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (126.94223054052654, 37.48223942209268, '2024-04-03 17:45:10.626960', 18, '2024-04-03 17:45:10.626960', 1162010100, '봉천역 2번 출구');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.02557072329816, 37.50340192199294, '2024-04-03 17:48:28.065426', 19, '2024-04-03 17:48:28.065426', 1168010100, '신논현 스타벅스');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.02708412619563, 37.497680196494095, '2024-04-03 17:53:18.486634', 20, '2024-04-03 17:53:18.486634', 1165010800, '강남역 8번 출구');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.09572042112057, 37.527647950597306, '2024-04-03 19:12:08.636535', 21, '2024-04-03 19:12:08.636535', 1171010200, '한강 정 가운데');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.11955435675057, 37.465578441326585, '2024-04-03 19:37:17.944639', 22, '2024-04-03 19:37:17.944639', 1168011100, '지하철 3출');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.10090787839107, 37.490125809005846, '2024-04-03 20:53:19.764970', 23, '2024-04-03 20:53:19.764970', 1168011500, '삼익아파트 놀이터 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.02928157371505, 37.49235922677371, '2024-04-03 20:57:35.148093', 24, '2024-04-03 20:57:35.148093', 1165010800, '강남역 할리스 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.02928722586029, 37.49235472033635, '2024-04-03 21:01:22.405272', 25, '2024-04-03 21:01:22.405272', 1165010800, '강남역 할리스 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (126.94223054052654, 37.48223942209268, '2024-04-03 21:04:27.130318', 26, '2024-04-03 21:04:27.130318', 1162010100, '봉천역 화장실 쪽 개찰구');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.02876954475518, 37.498815066085, '2024-04-03 21:55:52.437264', 144, '2024-04-03 21:55:52.437264', 1168010100, '강남역');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.02685890596896, 37.50033821635598, '2024-04-03 21:56:05.318846', 145, '2024-04-03 21:56:05.318846', 1168010100, '강남역');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.02790441789777, 37.498801758509934, '2024-04-03 22:01:29.663504', 146, '2024-04-03 22:01:29.663504', 1168010100, '강남 할리스');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.02557072329816, 37.50340192199294, '2024-04-03 22:34:35.026343', 147, '2024-04-03 22:34:35.026343', 1168010100, '스벅 2층 화장실 ');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.02790441789777, 37.498801758509934, '2024-04-03 22:46:44.743239', 148, '2024-04-03 22:46:44.743239', 1168010100, '할리스 지하 1층에 있을게용');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (126.93994884593278, 37.48658564987812, '2024-04-03 23:47:07.843188', 149, '2024-04-03 23:47:07.843188', 1162010100, '평산빌라 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (126.94033368295787, 37.48608128032472, '2024-04-04 00:04:18.235943', 150, '2024-04-04 00:04:18.235943', 1162010100, '삼성아파트 경비실 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (126.94580532371745, 37.487300277750606, '2024-04-04 00:12:01.193805', 151, '2024-04-04 00:12:01.193805', 1162010100, '새마을금고 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.02249477606732, 37.50416840247798, '2024-04-04 00:12:28.706221', 152, '2024-04-04 00:12:28.706221', 1165010700, 'cu 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.00194618641389, 37.54024217253536, '2024-04-04 00:16:22.003044', 153, '2024-04-04 00:16:22.003044', 1117013100, '한강진역 3출 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (126.9400180634194, 37.48486475941719, '2024-04-04 00:23:16.225005', 154, '2024-04-04 00:23:16.225005', 1162010100, 'CU 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.04728826573526, 37.45489389752071, '2024-04-04 00:23:59.736907', 155, '2024-04-04 00:23:59.736907', 1165010400, '청계산입구역 토니모리 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (126.94034495399374, 37.48612633642233, '2024-04-04 00:33:33.322134', 156, '2024-04-04 00:33:33.322134', 1162010100, '삼성아파트 101동 101호');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.0494624353792, 37.29787589884867, '2024-04-04 00:46:44.384096', 158, '2024-04-04 00:46:44.384096', 4111710300, '힐스테이트 광교 106동 1-2라인 자동문 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.03056766340863, 37.60970041292404, '2024-04-04 00:51:26.367688', 159, '2024-04-04 00:51:26.367688', 1130510100, '다이소 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (126.94090138923248, 37.4830812078289, '2024-04-04 00:54:27.524746', 160, '2024-04-04 00:54:27.524746', 1162010100, '봉천역 4번 출구');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (126.94279023912469, 37.48219013894667, '2024-04-04 00:59:08.914317', 161, '2024-04-04 00:59:08.914317', 1162010100, '국민은행 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.02802079042979, 37.61336807049734, '2024-04-04 01:00:25.916122', 162, '2024-04-04 01:00:25.916122', 1130510100, '영훈초 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (126.94067552470358, 37.482747721450515, '2024-04-04 01:00:43.562524', 163, '2024-04-04 01:00:43.562524', 1162010100, '봉천역 3번 출구');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.03031970468295, 37.61266473097521, '2024-04-04 01:03:20.720994', 164, '2024-04-04 01:03:20.720994', 1130510100, '미아사거리 3출');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.01016321462726, 37.55726612101578, '2024-04-04 01:06:22.439825', 165, '2024-04-04 01:06:22.439825', 1114016200, '약수역 1번출구');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (126.95218638057976, 37.481207710295244, '2024-04-04 01:06:24.474065', 166, '2024-04-04 01:06:24.474065', 1162010100, '서울대입구역 4번 출구');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.13010631487147, 37.51766801283029, '2024-04-04 01:08:15.442671', 167, '2024-04-04 01:08:15.442671', 1171011100, '올림픽공원역 1번출구');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (126.94221353600472, 37.482297979343834, '2024-04-04 01:10:58.825752', 168, '2024-04-04 01:10:58.825752', 1162010100, '스타벅스 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (126.94096942614563, 37.48282895943114, '2024-04-04 01:13:14.420078', 169, '2024-04-04 01:13:14.420078', 1162010100, '횡단보도 가운데');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (126.99739951544917, 37.48336626221709, '2024-04-04 01:13:54.828619', 170, '2024-04-04 01:13:54.828619', 1165010100, '방배역 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (126.94191855424381, 37.483613307275746, '2024-04-04 01:15:14.469348', 171, '2024-04-04 01:15:14.469348', 1162010100, '서도갈비 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (126.94327612954338, 37.48255978678659, '2024-04-04 03:22:27.358860', 172, '2024-04-04 03:22:27.358860', 1162010100, '버스정류장 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (126.97142013406084, 37.50555914025517, '2024-04-04 03:25:02.417532', 173, '2024-04-04 03:25:02.417532', 1159010500, '카페 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.11185667056358, 37.499828799646615, '2024-04-04 03:27:38.582960', 174, '2024-04-04 03:27:38.582960', 1171010700, '송파역 4번출구');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (126.8585679312222, 37.49518394366591, '2024-04-04 03:33:15.761206', 175, '2024-04-04 03:33:15.761206', 1153010700, '개봉역 1번 출구');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.00574294397822, 37.5475761841176, '2024-04-04 03:35:39.123456', 176, '2024-04-04 03:35:39.123456', 1114016200, '남산타운 아파트 놀이터');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.08931842305769, 37.53816989773338, '2024-04-04 03:38:34.503944', 177, '2024-04-04 03:38:34.503944', 1121510300, '이디야커피 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.02696013637491, 37.49880648281584, '2024-04-04 08:49:13.126440', 178, '2024-04-04 08:49:13.126440', 1165010800, '강남역 16번 출구');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.04345044106677, 37.50243262255343, '2024-04-04 09:02:00.359110', 179, '2024-04-04 09:02:00.359110', 1168010100, '위워크 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.02842427376856, 37.51279875050766, '2024-04-04 09:02:39.726965', 180, '2024-04-04 09:02:39.726965', 1168010800, '학동역 골목길 어귀');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.03976394956372, 37.50309165511286, '2024-04-04 09:02:52.841684', 181, '2024-04-04 09:02:52.841684', 1168010100, '리치웰호텔 정문 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.02881450637938, 37.49810326012481, '2024-04-04 09:07:03.234647', 182, '2024-04-04 09:07:03.234647', 1168010100, '강남역 1번 출구');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.03974081972336, 37.502127586829346, '2024-04-04 09:07:07.493662', 183, '2024-04-04 09:07:07.493662', 1168010100, '오렌지플래닛 바로 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.04128506688279, 37.492819660589646, '2024-04-04 09:07:58.922664', 184, '2024-04-04 09:07:58.922664', 1168010100, '스타벅스 도곡점');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.03622338534187, 37.5016151444768, '2024-04-04 09:13:03.226636', 185, '2024-04-04 09:13:03.226636', 1168010100, '역삼 선한목자병원');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.04049808405381, 37.50128038418925, '2024-04-04 09:15:12.327649', 186, '2024-04-04 09:15:12.327649', 1168010100, '역삼동 아나호텔');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.03876911144236, 37.50384883045437, '2024-04-04 09:31:04.157326', 187, '2024-04-04 09:31:04.157326', 1168010100, 'cu 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.03848566533486, 37.5024703845876, '2024-04-04 09:44:56.497560', 188, '2024-04-04 09:44:56.497560', 1168010100, '호텔 정문 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.0375019201692, 37.502804073085024, '2024-04-04 10:01:44.676455', 189, '2024-04-04 10:01:44.676455', 1168010100, '강남역 1출 앞');
INSERT INTO kkoma.location (x, y, created_at, id, modified_at, region_code, place_detail) VALUES (127.03949329219536, 37.50455137479631, '2024-04-04 10:56:37.990770', 190, '2024-04-04 10:56:37.990770', 1168010100, '호텔앞 정문');

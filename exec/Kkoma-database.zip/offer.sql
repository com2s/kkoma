create table offer
(
    cancelled_at datetime(6)                                        null,
    created_at   datetime(6)                                        null,
    id           bigint auto_increment
        primary key,
    member_id    bigint                                             null,
    modified_at  datetime(6)                                        null,
    product_id   bigint                                             null,
    replied_at   datetime(6)                                        null,
    status       enum ('SENT', 'CANCELLED', 'ACCEPTED', 'REJECTED') null,
    constraint FK3cow2cmfxb0nrt43hxm7yu1q3
        foreign key (product_id) references product (id),
    constraint FK4wmrom7fpqec5ul7pr7ngwe0v
        foreign key (member_id) references member (id)
);

INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-03 16:57:37.684214', 1, 2, '2024-04-03 16:57:37.684214', 2, null, 'SENT');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-03 16:58:34.236438', 2, 2, '2024-04-03 16:58:34.236438', 2, null, 'SENT');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-03 16:59:19.112997', 3, 1, '2024-04-03 16:59:19.112997', 2, null, 'SENT');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-03 17:04:51.243726', 4, 4, '2024-04-03 18:15:16.329987', 3, '2024-04-03 18:15:16.213535', 'ACCEPTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-03 17:11:54.569161', 5, 5, '2024-04-03 17:11:54.569161', 5, null, 'SENT');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-03 18:49:11.967355', 6, 18, '2024-04-03 18:54:03.735139', 11, '2024-04-03 18:54:03.713072', 'ACCEPTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-03 19:15:03.013337', 7, 5, '2024-04-03 19:41:05.329805', 21, '2024-04-03 19:41:05.319304', 'ACCEPTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-03 19:36:24.702637', 8, 1, '2024-04-03 19:36:56.863048', 20, '2024-04-03 19:36:56.837569', 'ACCEPTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-03 19:40:03.319630', 9, 5, '2024-04-03 19:40:57.621554', 22, '2024-04-03 19:40:57.609158', 'ACCEPTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-03 20:51:55.553398', 10, 1, '2024-04-03 21:15:24.072503', 19, '2024-04-03 21:15:24.015460', 'ACCEPTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-03 20:57:50.221822', 11, 5, '2024-04-03 20:58:32.294910', 24, '2024-04-03 20:58:32.285289', 'ACCEPTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-03 21:02:39.859642', 12, 5, '2024-04-03 21:03:54.196072', 25, '2024-04-03 21:03:54.186803', 'ACCEPTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-03 21:05:01.140160', 13, 15, '2024-04-04 02:08:10.051913', 26, '2024-04-04 02:08:09.897280', 'REJECTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-03 21:21:33.616326', 23, 18, '2024-04-03 21:31:00.888696', 23, '2024-04-03 21:31:00.745941', 'ACCEPTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-03 21:24:36.803155', 24, 18, '2024-04-03 21:31:00.889282', 23, '2024-04-03 21:31:00.865185', 'REJECTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-03 21:59:25.581344', 25, 5, '2024-04-03 21:59:25.581344', 146, null, 'SENT');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-03 22:18:36.806432', 26, 5, '2024-04-04 10:11:57.601149', 147, '2024-04-04 10:11:57.589586', 'REJECTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-03 22:35:02.112850', 27, 15, '2024-04-03 22:35:46.823851', 148, '2024-04-03 22:35:46.801049', 'ACCEPTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-03 22:47:46.196026', 28, 15, '2024-04-03 22:54:13.077497', 149, '2024-04-03 22:54:12.808346', 'ACCEPTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-03 23:25:07.438559', 29, 19, '2024-04-04 10:11:57.601073', 147, '2024-04-04 10:11:57.594713', 'ACCEPTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-04 00:56:48.084702', 30, 19, '2024-04-04 08:41:02.311101', 160, '2024-04-04 08:41:02.292337', 'ACCEPTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-04 00:59:22.471669', 31, 19, '2024-04-04 00:59:22.471669', 157, null, 'SENT');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-04 01:02:40.496286', 32, 5, '2024-04-04 01:02:40.496286', 163, null, 'SENT');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-04 02:02:04.031962', 33, 5, '2024-04-04 08:47:50.847421', 156, '2024-04-04 08:47:50.830189', 'REJECTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-04 02:07:29.231628', 34, 15, '2024-04-04 02:08:10.051913', 26, '2024-04-04 02:08:09.952021', 'ACCEPTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-04 02:20:36.015542', 35, 19, '2024-04-04 02:20:36.015542', 169, null, 'SENT');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-04 02:21:40.501137', 36, 19, '2024-04-04 02:21:40.501137', 169, null, 'SENT');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-04 04:33:17.717962', 37, 1, '2024-04-04 04:33:17.717962', 155, null, 'SENT');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-04 07:53:46.723387', 38, 107, '2024-04-04 08:47:50.847508', 156, '2024-04-04 08:47:50.836321', 'REJECTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-04 07:54:53.260393', 39, 107, '2024-04-04 08:47:50.846868', 156, '2024-04-04 08:47:50.837795', 'ACCEPTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-04 08:04:43.585716', 40, 107, '2024-04-04 10:21:10.430384', 154, '2024-04-04 10:21:10.418667', 'REJECTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-04 08:48:03.694471', 41, 109, '2024-04-04 08:48:03.694471', 167, null, 'SENT');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-04 09:03:19.059851', 42, 107, '2024-04-04 09:03:34.584008', 182, '2024-04-04 09:03:34.573724', 'ACCEPTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-04 09:09:41.801491', 43, 107, '2024-04-04 09:09:56.273901', 184, '2024-04-04 09:09:56.264501', 'ACCEPTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-04 09:35:28.333025', 45, 1, '2024-04-04 09:35:28.333025', 180, null, 'SENT');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-04 10:15:05.838935', 48, 5, '2024-04-04 10:15:56.628178', 171, '2024-04-04 10:15:56.618973', 'ACCEPTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-04 10:21:02.409195', 49, 5, '2024-04-04 10:21:10.430294', 154, '2024-04-04 10:21:10.423904', 'ACCEPTED');
INSERT INTO kkoma.offer (cancelled_at, created_at, id, member_id, modified_at, product_id, replied_at, status) VALUES (null, '2024-04-04 10:57:33.570529', 50, 5, '2024-04-04 10:58:03.747031', 191, '2024-04-04 10:58:03.738495', 'ACCEPTED');

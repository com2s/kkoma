create table category_preference
(
    category_id int    null,
    preference  float  not null,
    id          bigint auto_increment
        primary key,
    member_id   bigint null,
    constraint FK2m5gk8qbjnhfboo0s2dgq0bu7
        foreign key (category_id) references category (id),
    constraint FKke1h5rt3bvh0l86h72lj9he4c
        foreign key (member_id) references member (id)
);

create index category_preference_category_id_idx
    on category_preference (category_id);

create index category_preference_member_id_idx
    on category_preference (member_id);

create index category_preference_preference_idx
    on category_preference (preference);

INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (5, 0.6, 1, 2);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (23, 1, 2, 3);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (5, 0.5, 3, 1);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (23, 1, 4, 2);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (23, 1, 5, 1);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (20, 0.2, 6, 2);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (20, 0.4, 7, 3);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (5, 0.1, 8, 4);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (20, 1, 9, 4);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (20, 1, 10, 1);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (23, 1, 11, 5);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (20, 1, 12, 5);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (1, 0.3, 13, 4);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (1, 1, 14, 5);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (22, 1, 15, 5);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (15, 0.6, 16, 5);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (5, 0.3, 17, 5);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (8, 1, 18, 5);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (11, 0.2, 19, 14);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (11, 1, 20, 5);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (8, 0.2, 21, 14);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (22, 0.4, 22, 14);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (22, 0.2, 23, 15);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (8, 0.2, 24, 15);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (22, 0.2, 25, 16);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (19, 0.7, 26, 5);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (22, 1, 27, 1);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (23, 0.7, 28, 18);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (5, 0.1, 29, 18);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (22, 1, 30, 18);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (19, 0.2, 31, 14);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (11, 0.1, 32, 15);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (19, 0.2, 33, 16);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (11, 0.2, 34, 16);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (8, 0.1, 35, 16);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (19, 1, 36, 1);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (17, 0.3, 37, 5);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (17, 0.5, 38, 18);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (8, 0.3, 39, 1);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (17, 0.3, 40, 19);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (11, 1, 41, 19);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (8, 1, 42, 19);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (20, 1, 43, 19);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (19, 0.1, 44, 19);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (22, 1, 45, 19);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (23, 1, 46, 19);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (11, 1, 47, 1);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (18, 0.3, 49, 18);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (18, 0.6, 50, 5);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (18, 0.1, 51, 4);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (20, 0.2, 52, 14);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (10, 1, 53, 5);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (2, 0.6, 54, 5);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (10, 0.7, 55, 19);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (11, 0.8, 56, 18);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (10, 1, 57, 18);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (10, 1, 58, 1);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (4, 0.2, 59, 5);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (4, 0.8, 60, 19);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (2, 0.6, 61, 1);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (4, 0.2, 62, 1);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (13, 0.9, 63, 19);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (13, 1, 64, 18);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (13, 0.2, 65, 5);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (13, 0.5, 66, 1);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (2, 0.7, 67, 19);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (2, 0.7, 68, 18);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (4, 0.2, 69, 18);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (20, 0.6, 70, 18);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (16, 1, 71, 5);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (16, 1, 72, 19);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (16, 1, 73, 1);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (21, 0.9, 81, 19);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (21, 0.9, 82, 1);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (21, 0.5, 83, 5);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (21, 0.3, 84, 18);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (15, 0.5, 85, 19);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (15, 1, 86, 1);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (7, 0.5, 87, 1);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (18, 0.3, 88, 1);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (7, 1, 89, 5);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (21, 0.1, 90, 16);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (2, 0.1, 91, 16);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (7, 0.6, 92, 14);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (15, 0.3, 93, 16);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (4, 0.1, 94, 16);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (5, 0.1, 95, 16);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (20, 0.1, 96, 16);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (1, 0.1, 97, 18);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (13, 0.2, 98, 105);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (20, 0.1, 99, 105);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (19, 0.1, 100, 105);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (4, 0.1, 101, 105);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (23, 0.1, 102, 105);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (20, 0.1, 103, 106);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (19, 0.1, 104, 106);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (13, 0.1, 105, 106);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (4, 0.1, 106, 106);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (23, 0.1, 107, 106);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (14, 0.2, 108, 19);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (8, 0.1, 109, 107);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (22, 0.1, 110, 107);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (23, 1, 111, 107);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (1, 0.3, 112, 19);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (6, 0.1, 113, 19);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (2, 0.5, 114, 107);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (20, 0.1, 115, 108);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (22, 1, 116, 109);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (15, 0.2, 117, 109);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (20, 0.5, 118, 109);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (6, 0.1, 119, 5);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (14, 0.2, 120, 109);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (6, 0.2, 121, 109);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (18, 0.1, 122, 109);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (17, 0.3, 123, 107);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (7, 1, 124, 107);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (7, 0.3, 125, 19);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (7, 0.1, 126, 109);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (1, 0.2, 129, 1);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (17, 0.1, 131, 1);
INSERT INTO kkoma.category_preference (category_id, preference, id, member_id) VALUES (23, 0.3, 132, 114);
